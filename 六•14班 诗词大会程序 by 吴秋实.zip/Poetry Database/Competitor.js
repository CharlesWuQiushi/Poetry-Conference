//记录参赛选手信息
var competitors = [
    {
        name: "陶鲁玥",
        number: 9,
        score:0
    },
    {
        name: "杨周珂伊",
        number: 16,
        score:0
    },
    {
        name: "程牧远",
        number: 29,
        score:0
    },
    {
        name: "付又兮",
        number: 14,
        score:0
    },
    {
        name: "刘钰琳",
        number: 11,
        score:0
    },
    {
        name: "王梓霖",
        number: 33,
        score:0
    },
    {
        name: "吴雨馨",
        number: 13,
        score:0
    }
]

