# **手写板URL Protocol添加方式**
本[**诗词大会程序**](../Conference.htm)*填空题*部分的运行需要**手写板**的支持。
为此，请执行以下操作:<br/>

<b>1.</b>将本目录下的[**Handinput.zip压缩包**](./Handinput.zip)解压缩至 [**D:\Handinput\\**](D:/Handinput/) 文件夹中。<br/>
<b>2.</b>按下 <kbd>Win</kbd> + <kbd>R</kbd> 键，输入“*regedit*”，打开*Windows 注册表编辑器*；点击右上角的“*文件*”选项，选择“*导入*”，依次导入本目录下的[**Handinput.reg注册表文件**](./Handinput.reg)、[**Handinputover.reg注册表文件**](./Handinputover.reg)。

现在，可以使用本[**诗词大会程序**](../Conference.htm)进行手写答题了。